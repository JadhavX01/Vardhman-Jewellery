import { Facebook, Instagram, Twitter, Mail } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "motion/react";

export function Footer() {
  return (
    <footer className="bg-card border-t border-primary/20 mt-20">
      <div className="container mx-auto px-3 xs:px-4 py-8 xs:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 xs:gap-8">
          {/* Brand */}
          <div className="space-y-3 xs:space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 xs:w-10 xs:h-10 bg-gradient-to-br from-primary to-primary/60 rounded-full flex items-center justify-center">
                <span className="text-black text-sm xs:text-base">M</span>
              </div>
              <span className="text-xl xs:text-2xl text-primary tracking-wider">MOS Jewel</span>
            </div>
            <p className="text-muted-foreground text-xs xs:text-sm">
              Timeless elegance and exceptional craftsmanship in every piece.
            </p>
          </div>

          {/* Quick Links */}
          {/* <div>
            <h3 className="text-primary mb-3 xs:mb-4 text-sm xs:text-base">Shop</h3>
            <ul className="space-y-1 xs:space-y-2">
              <li>
                <Link to="/collections" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Collections
                </Link>
              </li>
              <li>
                <Link to="/rings" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Rings
                </Link>
              </li>
              <li>
                <Link to="/necklaces" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Necklaces
                </Link>
              </li>
              <li>
                <Link to="/bracelets" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Bracelets
                </Link>
              </li>
              <li>
                <Link to="/earrings" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Earrings
                </Link>
              </li>
            </ul>
          </div> */}

          {/* Customer Service */}
          <div>
            <h3 className="text-primary mb-3 xs:mb-4 text-sm xs:text-base">Customer Service</h3>
            <ul className="space-y-1 xs:space-y-2">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Shipping & Returns
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Size Guide
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  Care Instructions
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-300 text-xs xs:text-sm">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter - FIXED Mail Icon Issue */}
          <div>
            <h3 className="text-primary mb-3 xs:mb-4 text-sm xs:text-base">Stay Connected</h3>
            <p className="text-muted-foreground text-xs xs:text-sm mb-3 xs:mb-4">
              Subscribe to receive exclusive updates and offers.
            </p>
            <div className="flex gap-2 mb-3 xs:mb-4">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 min-w-0 px-3 xs:px-4 py-2 bg-background border border-input rounded-md text-xs xs:text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="px-3 xs:px-4 py-2 bg-primary text-black rounded-md hover:bg-primary/90 transition-colors duration-300 flex-shrink-0">
                <Mail className="w-3 h-3 xs:w-4 xs:h-4" />
              </button>
            </div>
            <div className="flex gap-3 xs:gap-4">
              <motion.a
                href="#"
                whileHover={{ scale: 1.2, color: "#D4AF37" }}
                className="text-muted-foreground transition-colors duration-300"
              >
                <Facebook className="w-4 h-4 xs:w-5 xs:h-5" />
              </motion.a>
              <motion.a
                href="#"
                whileHover={{ scale: 1.2, color: "#D4AF37" }}
                className="text-muted-foreground transition-colors duration-300"
              >
                <Instagram className="w-4 h-4 xs:w-5 xs:h-5" />
              </motion.a>
              <motion.a
                href="#"
                whileHover={{ scale: 1.2, color: "#D4AF37" }}
                className="text-muted-foreground transition-colors duration-300"
              >
                <Twitter className="w-4 h-4 xs:w-5 xs:h-5" />
              </motion.a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-primary/20 mt-6 xs:mt-8 pt-6 xs:pt-8 text-center">
          <p className="text-muted-foreground text-xs xs:text-sm">
            © 2025 MOS Jewel. All rights reserved. Crafted with excellence.
          </p>
        </div>
      </div>
    </footer>
  );
}