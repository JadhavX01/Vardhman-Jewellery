// import { Link, useNavigate } from "react-router-dom";
// import { ShoppingCart, Search, Heart, User, Menu, X } from "lucide-react";
// import { Button } from "../components/ui/button";
// import { useApp } from "../context/AppContext";
// import { motion, AnimatePresence } from "motion/react";
// import { useState } from "react";

// export function Header() {
//   const { cartCount, wishlistItems, setIsCartOpen } = useApp();
//   const navigate = useNavigate();
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

//   const navLinks = [
//     { name: "Home", path: "/" },
//     { name: "Collections", path: "/collections" },
//     { name: "Rings", path: "/rings" },
//     { name: "Necklaces", path: "/necklaces" },
//     { name: "Bracelets", path: "/bracelets" },
//     { name: "Earrings", path: "/earrings" },
//   ];

//   return (
//     <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
//       <div className="container mx-auto px-4 py-4">
//         <div className="flex items-center justify-between">
//           {/* Logo */}
//           <Link to="/" className="flex items-center space-x-2">
//             <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
//               <span className="text-xl">💎</span>
//             </div>
//             <span className="text-xl font-bold text-primary">LuxeJewels</span>
//           </Link>

//           {/* Desktop Navigation */}
//           <nav className="hidden md:flex items-center space-x-6">
//             {navLinks.map((link) => (
//               <Link
//                 key={link.path}
//                 to={link.path}
//                 className="text-sm hover:text-primary transition-colors duration-300 relative group"
//               >
//                 {link.name}
//                 <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></span>
//               </Link>
//             ))}
//           </nav>

//           {/* Action Buttons */}
//           <div className="flex items-center space-x-2">
//             {/* Search */}
//             <Button
//               variant="ghost"
//               size="icon"
//               onClick={() => navigate("/search")}
//               className="hover:bg-secondary hover:text-primary transition-all"
//             >
//               <Search className="h-5 w-5" />
//             </Button>

//             {/* Wishlist */}
//             <Button
//               variant="ghost"
//               size="icon"
//               onClick={() => navigate("/wishlist")}
//               className="hover:bg-secondary hover:text-primary transition-all relative"
//             >
//               <Heart className="h-5 w-5" />
//               {wishlistItems.length > 0 && (
//                 <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center">
//                   {wishlistItems.length}
//                 </span>
//               )}
//             </Button>

//             {/* Profile */}
//             <Button
//               variant="ghost"
//               size="icon"
//               onClick={() => navigate("/profile")}
//               className="hover:bg-secondary hover:text-primary transition-all"
//             >
//               <User className="h-5 w-5" />
//             </Button>

//             {/* Cart */}
//             <Button
//               variant="ghost"
//               size="icon"
//               onClick={() => setIsCartOpen(true)}
//               className="hover:bg-secondary hover:text-primary transition-all relative"
//             >
//               <ShoppingCart className="h-5 w-5" />
//               {cartCount > 0 && (
//                 <motion.span
//                   initial={{ scale: 0 }}
//                   animate={{ scale: 1 }}
//                   className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center"
//                 >
//                   {cartCount}
//                 </motion.span>
//               )}
//             </Button>

//             {/* Mobile Menu Toggle */}
//             <Button
//               variant="ghost"
//               size="icon"
//               onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
//               className="md:hidden hover:bg-secondary hover:text-primary transition-all"
//             >
//               {mobileMenuOpen ? (
//                 <X className="h-5 w-5" />
//               ) : (
//                 <Menu className="h-5 w-5" />
//               )}
//             </Button>
//           </div>
//         </div>

//         {/* Mobile Navigation */}
//         <AnimatePresence>
//           {mobileMenuOpen && (
//             <motion.nav
//               initial={{ opacity: 0, height: 0 }}
//               animate={{ opacity: 1, height: "auto" }}
//               exit={{ opacity: 0, height: 0 }}
//               className="md:hidden mt-4 pb-4 border-t border-border pt-4"
//             >
//               <div className="flex flex-col space-y-3">
//                 {navLinks.map((link) => (
//                   <Link
//                     key={link.path}
//                     to={link.path}
//                     onClick={() => setMobileMenuOpen(false)}
//                     className="text-sm hover:text-primary transition-colors duration-300 py-2"
//                   >
//                     {link.name}
//                   </Link>
//                 ))}
//               </div>
//             </motion.nav>
//           )}
//         </AnimatePresence>
//       </div>
//     </header>
//   );
// }
