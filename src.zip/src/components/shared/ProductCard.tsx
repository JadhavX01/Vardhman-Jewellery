import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Button } from "../ui/button";
import { Heart, ShoppingCart, Eye } from "lucide-react";
import { Product } from "../../types/Product";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist?: (product: Product) => void;
  isInWishlist?: boolean;
}

export function ProductCard({ 
  product, 
  onAddToCart, 
  onQuickView, 
  onToggleWishlist,
  isInWishlist = false 
}: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -8 }}
      className="group relative h-full"
    >
      <div className="relative bg-card border border-border rounded-lg overflow-hidden transition-all duration-300 hover:border-primary/50 hover:shadow-2xl hover:shadow-primary/20 h-full flex flex-col">
        {/* Image Container */}
        <div className="relative aspect-square overflow-hidden bg-secondary">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          {/* Overlay Actions */}
          <motion.div
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          >
            <motion.div
              initial={{ y: 20 }}
              whileHover={{ y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Button
                size="icon"
                variant="outline"
                className="bg-background/90 backdrop-blur-sm border-primary/50 hover:bg-primary hover:text-black hover:scale-110 transition-all duration-300"
                onClick={() => onQuickView(product)}
              >
                <Eye className="w-4 h-4" />
              </Button>
            </motion.div>
            <motion.div
              initial={{ y: 20 }}
              whileHover={{ y: 0 }}
              transition={{ delay: 0.15 }}
            >
              <Button
                size="icon"
                variant="outline"
                className="bg-background/90 backdrop-blur-sm border-primary/50 hover:bg-primary hover:text-black hover:scale-110 transition-all duration-300"
                onClick={() => onAddToCart(product)}
              >
                <ShoppingCart className="w-4 h-4" />
              </Button>
            </motion.div>
          </motion.div>

          {/* Wishlist Button */}
          {onToggleWishlist && (
            <motion.button
              className="absolute top-3 right-3 z-10"
              onClick={() => onToggleWishlist(product)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <div className="w-10 h-10 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center border border-border hover:border-primary/50 transition-all duration-300">
                <Heart
                  className={`w-5 h-5 transition-all duration-300 ${
                    isInWishlist ? "fill-primary text-primary" : "text-muted-foreground"
                  }`}
                />
              </div>
            </motion.button>
          )}

          {/* Category Badge */}
          <motion.div 
            className="absolute top-3 left-3"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <span className="px-3 py-1 bg-primary/90 backdrop-blur-sm text-black text-xs uppercase tracking-wider rounded-full">
              {product.category}
            </span>
          </motion.div>
        </div>

        {/* Product Info */}
        <div className="p-5 flex-1 flex flex-col">
          <h3 className="text-lg text-foreground mb-2 group-hover:text-primary transition-colors duration-300">
            {product.name}
          </h3>
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">
            {product.description}
          </p>
          <div className="flex items-center justify-between mt-auto">
            <span className="text-2xl text-primary">
              ${product.price.toLocaleString()}
            </span>
            <Button
              size="sm"
              className="bg-primary text-black hover:bg-primary/90 transition-all duration-300 hover:scale-105"
              onClick={() => onAddToCart(product)}
            >
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
