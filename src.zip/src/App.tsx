import { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";
import { Cart } from "./components/shared/Cart";
import { ProductQuickView } from "./components/shared/ProductQuickView";
import { Toaster, toast } from "sonner";
import ProtectedRoute from "./components/ProtectedRoute";

// Pages
import { HomePage } from "./components/pages/HomePage";
import { CollectionsPage } from "./components/pages/CollectionsPage";
import { RingsPage } from "./components/pages/RingsPage";
import { NecklacesPage } from "./components/pages/NecklacesPage";
import { BraceletsPage } from "./components/pages/BraceletsPage";
import { EarringsPage } from "./components/pages/EarringsPage";
import { SearchPage } from "./components/pages/SearchPage";
import ProfilePage from "./components/pages/ProfilePage.jsx";
import { WishlistPage } from "./components/pages/WishlistPage";

// Auth Pages
import LoginPage from "./components/pages/LoginPage";
import RegisterPage from "./components/pages/RegisterPage";
import VerifyOtpPage from "./components/pages/VerifyOtpPage";
import ForgotPasswordPage from "./components/pages/ForgotPasswordPage";
import ResetPasswordPage from "./components/pages/ResetPasswordPage";
import StaffAdminLoginPage from "./components/pages/StaffAdminLoginPage";

// Admin Pages
import AdminDashboard from "./components/pages/AdminDashboard";

export default function App() {
  const [cartItems, setCartItems] = useState([]);
  const [wishlistItems, setWishlistItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);

  // Add to cart
  const handleAddToCart = (product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        toast.success(`Updated ${product.name} quantity in cart`);
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      toast.success(`${product.name} added to cart`);
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  // Update quantity
  const handleUpdateQuantity = (id, quantity) => {
    if (quantity <= 0) return;
    setCartItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, quantity } : item))
    );
  };

  // Remove item from cart
  const handleRemoveItem = (id) => {
    const item = cartItems.find((item) => item.id === id);
    if (item) toast.error(`${item.name} removed from cart`);
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Quick view
  const handleQuickView = (product) => {
    setSelectedProduct(product);
    setIsQuickViewOpen(true);
  };

  // Wishlist toggle
  const handleToggleWishlist = (product) => {
    setWishlistItems((prev) => {
      const isInWishlist = prev.some((item) => item.id === product.id);
      if (isInWishlist) {
        toast.error(`${product.name} removed from wishlist`);
        return prev.filter((item) => item.id !== product.id);
      }
      toast.success(`${product.name} added to wishlist`);
      return [...prev, product];
    });
  };

  const isInWishlist = (productId) => {
    return wishlistItems.some((item) => item.id === productId);
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />

      <Routes>
        {/* ========== AUTHENTICATION ROUTES ========== */}
        
        {/* Customer Login */}
        <Route path="/login" element={<LoginPage />} />
        
        {/* Customer Registration */}
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Verify OTP */}
        <Route path="/verify-otp" element={<VerifyOtpPage />} />
        
        {/* Forgot Password */}
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        
        {/* Reset Password */}
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        
        {/* Staff & Admin Login - NEW */}
        <Route path="/staff-login" element={<StaffAdminLoginPage />} />
        
        {/* ========== ADMIN ROUTES ========== */}
        
        {/* Admin Dashboard - Protected */}
        <Route
          path="/admin-dashboard"
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        
        {/* ========== REDIRECT ROUTES ========== */}
        
        {/* Redirect /home to / */}
        <Route path="/home" element={<Navigate to="/" replace />} />
        
        {/* ========== SHOP ROUTES ========== */}
        
        {/* Home Page */}
        <Route
          path="/"
          element={
            <HomePage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Collections */}
        <Route
          path="/collections"
          element={
            <CollectionsPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Rings */}
        <Route
          path="/rings"
          element={
            <RingsPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Necklaces */}
        <Route
          path="/necklaces"
          element={
            <NecklacesPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Bracelets */}
        <Route
          path="/bracelets"
          element={
            <BraceletsPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Earrings */}
        <Route
          path="/earrings"
          element={
            <EarringsPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Search */}
        <Route
          path="/search"
          element={
            <SearchPage
              onAddToCart={handleAddToCart}
              onQuickView={handleQuickView}
              onToggleWishlist={handleToggleWishlist}
              isInWishlist={isInWishlist}
            />
          }
        />
        
        {/* Profile - Protected */}
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <ProfilePage />
            </ProtectedRoute>
          }
        />
        
        {/* Wishlist - Protected */}
        <Route
          path="/wishlist"
          element={
            <ProtectedRoute>
              <WishlistPage
                wishlistItems={wishlistItems}
                onAddToCart={handleAddToCart}
                onQuickView={handleQuickView}
                onToggleWishlist={handleToggleWishlist}
              />
            </ProtectedRoute>
          }
        />
      </Routes>

      <Footer />

      {/* Cart Drawer */}
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
      />

      {/* Quick View Modal */}
      <ProductQuickView
        product={selectedProduct}
        isOpen={isQuickViewOpen}
        onClose={() => setIsQuickViewOpen(false)}
        onAddToCart={handleAddToCart}
      />

      <Toaster position="top-right" richColors />
    </div>
  );
}