// import { motion } from "motion/react";
// import { Button } from "../components/ui/button";
// import { useNavigate } from "react-router-dom";
// import { Sparkles, Award, Shield, Truck } from "lucide-react";
// import { products } from "../data/products";
// import { ProductCard } from "../shared/ProductCard";
// import { useState } from "react";
// import { ProductQuickView } from "../shared/ProductQuickView";

// export function HomePage() {
//   const navigate = useNavigate();
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);

//   const featuredProducts = products.slice(0, 4);

//   const categories = [
//     {
//       name: "Rings",
//       image: "https://images.unsplash.com/photo-1758995115475-7b7d6eb060ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwcmluZyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU5OTk5NzM2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
//       path: "/rings",
//     },
//     {
//       name: "Necklaces",
//       image: "https://images.unsplash.com/photo-1590156118368-607652ab307a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWFtb25kJTIwbmVja2xhY2UlMjBsdXh1cnl8ZW58MXx8fHwxNzU5OTMxMzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
//       path: "/necklaces",
//     },
//     {
//       name: "Bracelets",
//       image: "https://images.unsplash.com/photo-1758995119744-6454f091303f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqZXdlbHJ5JTIwYnJhY2VsZXQlMjBjb2xsZWN0aW9ufGVufDF8fHx8MTc1OTk5OTczNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
//       path: "/bracelets",
//     },
//     {
//       name: "Earrings",
//       image: "https://images.unsplash.com/photo-1684439673104-f5d22791c71a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZWFycmluZ3N8ZW58MXx8fHwxNzU5OTk5NzQxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
//       path: "/earrings",
//     },
//   ];

//   const features = [
//     {
//       icon: Award,
//       title: "Premium Quality",
//       description: "Certified authentic jewelry",
//     },
//     {
//       icon: Shield,
//       title: "Secure Payment",
//       description: "100% secure transactions",
//     },
//     {
//       icon: Truck,
//       title: "Free Shipping",
//       description: "On orders over $500",
//     },
//     {
//       icon: Sparkles,
//       title: "Lifetime Warranty",
//       description: "On all our products",
//     },
//   ];

//   const handleQuickView = (product) => {
//     setSelectedProduct(product);
//     setIsQuickViewOpen(true);
//   };

//   return (
//     <div>
//       {/* Hero Section */}
//       <section
//         className="relative h-[600px] flex items-center justify-center overflow-hidden"
//         style={{
//           backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1758631279366-8e8aeaf94082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBqZXdlbHJ5JTIwc3RvcmUlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NTk5OTk3MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//         }}
//       >
//         <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-background" />
        
//         <div className="container mx-auto px-4 relative z-10 text-center">
//           <motion.div
//             initial={{ opacity: 0, y: 30 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.8 }}
//           >
//             <h1 className="text-5xl md:text-7xl mb-6 text-white">
//               Timeless <span className="text-primary">Elegance</span>
//             </h1>
//             <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-2xl mx-auto">
//               Discover our exquisite collection of handcrafted jewelry pieces that
//               celebrate life's precious moments
//             </p>
//             <div className="flex gap-4 justify-center flex-wrap">
//               <Button
//                 size="lg"
//                 className="bg-primary hover:bg-primary/90 text-primary-foreground"
//                 onClick={() => navigate("/collections")}
//               >
//                 <Sparkles className="mr-2 h-5 w-5" />
//                 Explore Collections
//               </Button>
//               <Button
//                 size="lg"
//                 variant="outline"
//                 className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
//                 onClick={() => navigate("/search")}
//               >
//                 Shop Now
//               </Button>
//             </div>
//           </motion.div>
//         </div>

//         {/* Animated particles effect */}
//         <div className="absolute inset-0 pointer-events-none">
//           {[...Array(20)].map((_, i) => (
//             <motion.div
//               key={i}
//               className="absolute w-1 h-1 bg-primary rounded-full"
//               style={{
//                 left: `${Math.random() * 100}%`,
//                 top: `${Math.random() * 100}%`,
//               }}
//               animate={{
//                 y: [0, -30, 0],
//                 opacity: [0, 1, 0],
//               }}
//               transition={{
//                 duration: 3 + Math.random() * 2,
//                 repeat: Infinity,
//                 delay: Math.random() * 2,
//               }}
//             />
//           ))}
//         </div>
//       </section>

//       {/* Features */}
//       <section className="py-12 bg-card">
//         <div className="container mx-auto px-4">
//           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
//             {features.map((feature, index) => (
//               <motion.div
//                 key={feature.title}
//                 initial={{ opacity: 0, y: 20 }}
//                 whileInView={{ opacity: 1, y: 0 }}
//                 viewport={{ once: true }}
//                 transition={{ delay: index * 0.1 }}
//                 className="flex flex-col items-center text-center p-6 rounded-lg bg-background hover:bg-secondary transition-colors"
//               >
//                 <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
//                   <feature.icon className="h-7 w-7 text-primary" />
//                 </div>
//                 <h3 className="text-lg mb-2">{feature.title}</h3>
//                 <p className="text-sm text-muted-foreground">{feature.description}</p>
//               </motion.div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Categories */}
//       <section className="py-16">
//         <div className="container mx-auto px-4">
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             whileInView={{ opacity: 1, y: 0 }}
//             viewport={{ once: true }}
//             className="text-center mb-12"
//           >
//             <h2 className="text-4xl mb-4">Shop by Category</h2>
//             <p className="text-muted-foreground">
//               Discover our curated collections of fine jewelry
//             </p>
//           </motion.div>

//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//             {categories.map((category, index) => (
//               <motion.div
//                 key={category.name}
//                 initial={{ opacity: 0, scale: 0.9 }}
//                 whileInView={{ opacity: 1, scale: 1 }}
//                 viewport={{ once: true }}
//                 transition={{ delay: index * 0.1 }}
//                 whileHover={{ scale: 1.05 }}
//                 onClick={() => navigate(category.path)}
//                 className="relative h-80 rounded-lg overflow-hidden cursor-pointer group"
//               >
//                 <div
//                   className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
//                   style={{ backgroundImage: `url(${category.image})` }}
//                 />
//                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
//                 <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
//                   <h3 className="text-2xl mb-2">{category.name}</h3>
//                   <Button
//                     variant="outline"
//                     className="border-white text-white hover:bg-white hover:text-black"
//                   >
//                     Explore
//                   </Button>
//                 </div>
//               </motion.div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Featured Products */}
//       <section className="py-16 bg-card">
//         <div className="container mx-auto px-4">
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             whileInView={{ opacity: 1, y: 0 }}
//             viewport={{ once: true }}
//             className="text-center mb-12"
//           >
//             <h2 className="text-4xl mb-4">Featured Collection</h2>
//             <p className="text-muted-foreground">
//               Our most popular and exquisite pieces
//             </p>
//           </motion.div>

//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//             {featuredProducts.map((product) => (
//               <ProductCard
//                 key={product.id}
//                 product={product}
//                 onQuickView={handleQuickView}
//               />
//             ))}
//           </div>

//           <div className="text-center mt-12">
//             <Button
//               size="lg"
//               variant="outline"
//               onClick={() => navigate("/collections")}
//               className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
//             >
//               View All Products
//             </Button>
//           </div>
//         </div>
//       </section>

//       {/* Newsletter */}
//       <section className="py-16">
//         <div className="container mx-auto px-4">
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             whileInView={{ opacity: 1, y: 0 }}
//             viewport={{ once: true }}
//             className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl p-12 text-center border border-primary/30"
//           >
//             <h2 className="text-3xl mb-4">Join Our Exclusive Club</h2>
//             <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
//               Subscribe to receive updates on new arrivals, special offers, and
//               exclusive jewelry collections
//             </p>
//             <div className="flex gap-3 max-w-md mx-auto">
//               <input
//                 type="email"
//                 placeholder="Enter your email"
//                 className="flex-1 px-4 py-3 rounded-lg bg-background border border-border focus:outline-none focus:border-primary"
//               />
//               <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-8">
//                 Subscribe
//               </Button>
//             </div>
//           </motion.div>
//         </div>
//       </section>

//       <ProductQuickView
//         product={selectedProduct}
//         isOpen={isQuickViewOpen}
//         onClose={() => setIsQuickViewOpen(false)}
//       />
//     </div>
//   );
// }
