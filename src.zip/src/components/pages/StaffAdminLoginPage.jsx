import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../../utils/api";
import { useAuth } from "../../context/AuthContext";
import { toast } from "sonner";
import { Eye, EyeOff, ArrowLeft } from "lucide-react";

const StaffAdminLoginPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ login: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    // Validation
    if (!form.login || form.login.trim() === "") {
      setError("Username/Login ID is required");
      setLoading(false);
      return;
    }

    if (!form.password || form.password.trim() === "") {
      setError("Password is required");
      setLoading(false);
      return;
    }

    try {
      // Call backend staff/admin login endpoint
      const res = await API.post("/api/auth/staff-admin/login", {
        login: form.login,
        password: form.password,
      });

      if (res.data.token) {
        const userData = {
          token: res.data.token,
          ...res.data.user, // userId, name, login, userType
        };

        // Store token and user data in AuthContext
        login(userData);

        // Store in localStorage for persistence
        localStorage.setItem("vardhaman_user", JSON.stringify(userData));

        // Show appropriate message based on user type
        const userType = res.data.user.userType;
        if (userType === "ADMIN") {
          toast.success("Admin login successful!");
        } else {
          toast.success("Staff login successful!");
        }

        // Redirect based on user type
        setTimeout(() => {
          if (userType === "ADMIN") {
            navigate("/admin-dashboard");
          } else {
            navigate("/staff-dashboard");
          }
        }, 500);
      }
    } catch (err) {
      const errorMsg =
        err.response?.data?.message ||
        "Login failed. Please check your credentials.";
      setError(errorMsg);
      toast.error(errorMsg);
      console.error("Staff/Admin login error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <div className="bg-white shadow-md rounded-lg p-8 w-full max-w-md">
        {/* Header */}
        <div className="mb-6">
          <Link
            to="/login"
            className="inline-flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Customer Login
          </Link>
          <h2 className="text-2xl font-semibold">Staff & Admin Login</h2>
          <p className="text-gray-600 text-sm mt-2">
            Login with your credentials provided by management
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm border border-red-300">
            {error}
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username/Login ID Field */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Username / Login ID *
            </label>
            <input
              type="text"
              name="login"
              value={form.login}
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your username"
              required
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-1">
              Provided by your administrator
            </p>
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-sm font-medium mb-1">
              Password *
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={form.password}
                onChange={handleChange}
                className="w-full border border-gray-300 rounded px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your password"
                required
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                tabIndex="-1"
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition disabled:bg-gray-400 font-medium"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        {/* Divider */}
        <div className="mt-6 pt-6 border-t">
          <p className="text-center text-xs text-gray-500 mb-3">
            Are you a customer?
          </p>
          <Link
            to="/login"
            className="block w-full border-2 border-gray-300 text-gray-700 py-2 rounded hover:bg-gray-50 transition font-medium text-center"
          >
            Customer Login
          </Link>
        </div>

        {/* Help Text */}
        <div className="mt-6 p-4 bg-blue-50 rounded">
          <p className="text-xs text-gray-600">
            <strong>Need help?</strong> Contact your administrator if you don't
            have login credentials or have forgotten your password.
          </p>
        </div>
      </div>
    </div>
  );
};

export default StaffAdminLoginPage;