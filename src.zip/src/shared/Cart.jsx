// import { X, Plus, Minus, ShoppingBag, Trash2 } from "lucide-react";
// import { Button } from "../components/ui/button";
// import { useApp } from "../context/AppContext";
// import { motion, AnimatePresence } from "motion/react";
// import { ImageWithFallback } from "../components/figma/ImageWithFallback";
// import { Separator } from "../components/ui/separator";

// export function Cart() {
//   const {
//     isCartOpen,
//     setIsCartOpen,
//     cartItems,
//     updateQuantity,
//     removeFromCart,
//     cartTotal,
//     clearCart,
//   } = useApp();

//   return (
//     <AnimatePresence>
//       {isCartOpen && (
//         <>
//           {/* Backdrop */}
//           <motion.div
//             initial={{ opacity: 0 }}
//             animate={{ opacity: 1 }}
//             exit={{ opacity: 0 }}
//             onClick={() => setIsCartOpen(false)}
//             className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
//           />

//           {/* Cart Panel */}
//           <motion.div
//             initial={{ x: "100%" }}
//             animate={{ x: 0 }}
//             exit={{ x: "100%" }}
//             transition={{ type: "spring", damping: 25, stiffness: 200 }}
//             className="fixed right-0 top-0 h-full w-full md:w-[450px] bg-card border-l border-border z-50 shadow-2xl flex flex-col"
//           >
//             {/* Header */}
//             <div className="p-6 border-b border-border">
//               <div className="flex items-center justify-between">
//                 <div className="flex items-center gap-2">
//                   <ShoppingBag className="h-5 w-5 text-primary" />
//                   <h2 className="text-xl">Shopping Cart</h2>
//                 </div>
//                 <Button
//                   variant="ghost"
//                   size="icon"
//                   onClick={() => setIsCartOpen(false)}
//                 >
//                   <X className="h-5 w-5" />
//                 </Button>
//               </div>
//               {cartItems.length > 0 && (
//                 <p className="text-sm text-muted-foreground mt-2">
//                   {cartItems.length} {cartItems.length === 1 ? "item" : "items"} in cart
//                 </p>
//               )}
//             </div>

//             {/* Cart Items */}
//             <div className="flex-1 overflow-y-auto p-6">
//               {cartItems.length === 0 ? (
//                 <div className="flex flex-col items-center justify-center h-full text-center">
//                   <ShoppingBag className="h-16 w-16 text-muted-foreground mb-4" />
//                   <h3 className="text-lg mb-2">Your cart is empty</h3>
//                   <p className="text-sm text-muted-foreground mb-4">
//                     Add some beautiful jewelry to get started
//                   </p>
//                   <Button onClick={() => setIsCartOpen(false)}>
//                     Continue Shopping
//                   </Button>
//                 </div>
//               ) : (
//                 <div className="space-y-4">
//                   {cartItems.map((item) => (
//                     <motion.div
//                       key={item.id}
//                       initial={{ opacity: 0, x: 20 }}
//                       animate={{ opacity: 1, x: 0 }}
//                       exit={{ opacity: 0, x: -20 }}
//                       className="flex gap-4 bg-background p-4 rounded-lg border border-border"
//                     >
//                       <ImageWithFallback
//                         src={item.image}
//                         alt={item.name}
//                         className="w-20 h-20 object-cover rounded-md"
//                       />
//                       <div className="flex-1">
//                         <h4 className="text-sm mb-1">{item.name}</h4>
//                         <p className="text-xs text-muted-foreground mb-2">
//                           {item.category}
//                         </p>
//                         <p className="text-sm text-primary font-semibold">
//                           ${item.price.toLocaleString()}
//                         </p>
//                       </div>
//                       <div className="flex flex-col justify-between items-end">
//                         <Button
//                           variant="ghost"
//                           size="icon"
//                           className="h-6 w-6"
//                           onClick={() => removeFromCart(item.id)}
//                         >
//                           <Trash2 className="h-3 w-3" />
//                         </Button>
//                         <div className="flex items-center gap-2">
//                           <Button
//                             variant="outline"
//                             size="icon"
//                             className="h-6 w-6"
//                             onClick={() =>
//                               updateQuantity(item.id, item.quantity - 1)
//                             }
//                             disabled={item.quantity <= 1}
//                           >
//                             <Minus className="h-3 w-3" />
//                           </Button>
//                           <span className="text-sm w-6 text-center">
//                             {item.quantity}
//                           </span>
//                           <Button
//                             variant="outline"
//                             size="icon"
//                             className="h-6 w-6"
//                             onClick={() =>
//                               updateQuantity(item.id, item.quantity + 1)
//                             }
//                           >
//                             <Plus className="h-3 w-3" />
//                           </Button>
//                         </div>
//                       </div>
//                     </motion.div>
//                   ))}
//                 </div>
//               )}
//             </div>

//             {/* Footer */}
//             {cartItems.length > 0 && (
//               <div className="p-6 border-t border-border bg-background">
//                 <div className="space-y-4">
//                   <div className="flex justify-between items-center">
//                     <span className="text-muted-foreground">Subtotal</span>
//                     <span className="text-lg">${cartTotal.toLocaleString()}</span>
//                   </div>
//                   <Separator />
//                   <div className="flex justify-between items-center">
//                     <span className="font-semibold">Total</span>
//                     <span className="text-xl text-primary font-semibold">
//                       ${cartTotal.toLocaleString()}
//                     </span>
//                   </div>
//                   <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
//                     Proceed to Checkout
//                   </Button>
//                   <Button
//                     variant="outline"
//                     className="w-full"
//                     onClick={clearCart}
//                   >
//                     Clear Cart
//                   </Button>
//                 </div>
//               </div>
//             )}
//           </motion.div>
//         </>
//       )}
//     </AnimatePresence>
//   );
// }
