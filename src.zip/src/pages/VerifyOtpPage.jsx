// frontend/src/components/pages/VerifyOtpPage.jsx
import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import API from "../../utils/api";
import { useAuth } from "../../context/AuthContext";

const VerifyOtpPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  
  // Get email/mobile from registration page
  const loginKey = location.state?.email || location.state?.mobile || "";
  
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [resending, setResending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await API.post("/auth/verify-otp", {
        login: loginKey,
        otp: otp,
      });

      if (res.data.token) {
        // Save token and user data using AuthContext
        login({
          token: res.data.token,
          redirectTo: res.data.redirectTo,
        });

        // Navigate to the route backend specified
        navigate(res.data.redirectTo || "/");
      }
    } catch (err) {
      setError(
        err.response?.data?.message || "OTP verification failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setResending(true);
    setError("");
    
    try {
      // Call register again to resend OTP (your backend sends OTP on /register)
      await API.post("/auth/register", {
        email: loginKey.includes("@") ? loginKey : undefined,
        mobile: !loginKey.includes("@") ? loginKey : undefined,
        name: "Resend", // dummy data for resend
        password: "dummy", // your backend will send OTP again
      });
      
      alert("OTP resent successfully! Check your email/SMS.");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to resend OTP");
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <div className="bg-white shadow-md rounded-lg p-8 w-96">
        <h2 className="text-2xl font-semibold text-center mb-6">
          Verify OTP
        </h2>

        <p className="text-sm text-gray-600 mb-4 text-center">
          Enter the OTP sent to <strong>{loginKey}</strong>
        </p>

        {error && (
          <div className="bg-red-100 text-red-700 p-2 rounded mb-3 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter 6-digit OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            maxLength={6}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4 text-center text-lg tracking-widest"
            required
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition disabled:bg-gray-400"
          >
            {loading ? "Verifying..." : "Verify OTP"}
          </button>
        </form>

        <div className="mt-4 text-center">
          <button
            onClick={handleResendOtp}
            disabled={resending}
            className="text-blue-600 hover:underline text-sm disabled:text-gray-400"
          >
            {resending ? "Resending..." : "Resend OTP"}
          </button>
        </div>

        <div className="mt-4 text-center text-sm">
          <Link to="/login" className="text-blue-600 hover:underline">
            Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VerifyOtpPage;