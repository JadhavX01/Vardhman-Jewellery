import { motion } from "motion/react";
import { ProductCard } from "../shared/ProductCard";
import { Product } from "../../types/Product";
import { allProducts } from "../../data/products";
import { ArrowRight, Sparkles, Award, Shield, Truck } from "lucide-react";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";

interface HomePageProps {
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: (productId: number) => boolean;
}

export function HomePage({ onAddToCart, onQuickView, onToggleWishlist, isInWishlist }: HomePageProps) {
  const featuredProducts = allProducts.slice(0, 8);

  const categories = [
    { name: "Rings", image: "https://images.unsplash.com/photo-1758995116142-c626a962a682?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwamV3ZWxyeSUyMHJpbmclMjBsdXh1cnl8ZW58MXx8fHwxNzYwMDAxNTE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral", path: "/rings" },
    { name: "Necklaces", image: "https://images.unsplash.com/photo-1590156118368-607652ab307a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWFtb25kJTIwbmVja2xhY2UlMjBsdXh1cnl8ZW58MXx8fHwxNzU5OTMxMzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral", path: "/necklaces" },
    { name: "Bracelets", image: "https://images.unsplash.com/photo-1629587424599-ee8806a66127?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBicmFjZWxldCUyMGdvbGR8ZW58MXx8fHwxNzU5OTM3NzI1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral", path: "/bracelets" },
    { name: "Earrings", image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800&q=80", path: "/earrings" },
  ];

  const features = [
    { icon: Award, title: "Premium Quality", description: "Handcrafted with the finest materials" },
    { icon: Shield, title: "Lifetime Warranty", description: "We guarantee our craftsmanship" },
    { icon: Truck, title: "Free Shipping", description: "On all orders over $500" },
    { icon: Sparkles, title: "Exclusive Designs", description: "Unique pieces you won't find elsewhere" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Parallax Effect */}
        <motion.div
          className="absolute inset-0 z-0"
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
        >
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1758631279564-785e98313f8b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBqZXdlbHJ5JTIwZGlhbW9uZHMlMjBlbGVnYW50fGVufDF8fHx8MTc2MDAwMTUxOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/90" />
        </motion.div>

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.div 
              className="inline-block mb-6"
              animate={{ 
                boxShadow: [
                  "0 0 20px rgba(212, 175, 55, 0.3)",
                  "0 0 40px rgba(212, 175, 55, 0.5)",
                  "0 0 20px rgba(212, 175, 55, 0.3)",
                ]
              }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <span className="px-6 py-2 bg-primary/10 border border-primary/30 text-primary text-sm uppercase tracking-widest rounded-full backdrop-blur-sm">
                Timeless Elegance Since 1990
              </span>
            </motion.div>
            <h1 className="text-5xl md:text-7xl mb-6 text-foreground">
              Discover Luxury
              <span className="block text-primary mt-2">That Lasts Forever</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Exquisite handcrafted jewelry pieces that celebrate life's most precious moments
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Link to="/collections">
                <Button 
                  size="lg" 
                  className="bg-primary text-black hover:bg-primary/90 transition-all duration-300 hover:scale-105"
                >
                  Explore Collection
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="outline"
                className="border-primary/50 hover:bg-primary hover:text-black transition-all duration-300"
              >
                Custom Design
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center">
            <motion.div
              className="w-1.5 h-1.5 bg-primary rounded-full mt-2"
              animate={{ y: [0, 16, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            />
          </div>
        </motion.div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-gradient-to-b from-background to-secondary/20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4">
              Shop by <span className="text-primary">Category</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Explore our curated collections of fine jewelry
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <Link to={category.path}>
                  <div className="group relative h-80 rounded-2xl overflow-hidden border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-2xl hover:shadow-primary/20">
                    <div 
                      className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                      style={{ backgroundImage: `url('${category.image}')` }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                    <div className="absolute inset-0 flex items-end p-6">
                      <div>
                        <h3 className="text-2xl text-foreground mb-2 group-hover:text-primary transition-colors">
                          {category.name}
                        </h3>
                        <div className="flex items-center text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <span className="text-sm">Explore</span>
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-4">
              Featured <span className="text-primary">Collection</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Discover our most popular pieces, loved by jewelry enthusiasts worldwide
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
                onToggleWishlist={onToggleWishlist}
                isInWishlist={isInWishlist(product.id)}
              />
            ))}
          </div>

          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <Link to="/collections">
              <Button 
                size="lg" 
                variant="outline"
                className="border-primary/50 hover:bg-primary hover:text-black transition-all duration-300"
              >
                View All Products
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-b from-secondary/20 to-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <motion.div
                  className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-full flex items-center justify-center mx-auto mb-4"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <feature.icon className="w-8 h-8 text-primary" />
                </motion.div>
                <h3 className="text-xl mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
     {/* Newsletter Section */}
<section className="py-20">
  <div className="container mx-auto px-4">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="max-w-3xl mx-auto text-center bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-6 md:p-12"
    >
      <Sparkles className="w-12 h-12 text-primary mx-auto mb-6" />
      <h2 className="text-3xl md:text-4xl mb-4">
        Join Our Exclusive Club
      </h2>
      <p className="text-muted-foreground text-lg mb-8">
        Subscribe to receive exclusive offers, styling tips, and be the first to know about new arrivals
      </p>
      
      {/* FIXED: Responsive input + button layout */}
      <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
        <input
          type="email"
          placeholder="Enter your email"
          className="flex-1 px-4 sm:px-6 py-3 sm:py-4 bg-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-base"
        />
        <Button 
          size="lg"
          className="bg-primary text-black hover:bg-primary/90 transition-all duration-300 hover:scale-105 whitespace-nowrap min-w-0 sm:min-w-[120px]"
        >
          Subscribe
        </Button>
      </div>
    </motion.div>
  </div>
</section>
    </div>
  );
}
