import { ShoppingCart, Search, Menu, Heart, User, X } from "lucide-react";
import { Button } from "../ui/button";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export function Header({ cartCount, onCartClick }: HeaderProps) {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: "Collections", path: "/collections" },
    { name: "Rings", path: "/rings" },
    { name: "Necklaces", path: "/necklaces" },
    { name: "Bracelets", path: "/bracelets" },
    { name: "Earrings", path: "/earrings" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-b border-primary/20">
      <div className="container mx-auto px-3 xs:px-4">
        <div className="flex items-center justify-between h-16 xs:h-20">
          {/* Logo & Mobile Menu */}
          <div className="flex items-center gap-4 xs:gap-6">
            <button 
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 xs:w-6 xs:h-6 text-primary" />
              ) : (
                <Menu className="w-5 h-5 xs:w-6 xs:h-6 text-primary" />
              )}
            </button>
            <Link to="/" className="flex items-center gap-2 group">
              <motion.div 
                className="w-8 h-8 xs:w-10 xs:h-10 bg-gradient-to-br from-primary to-primary/60 rounded-full flex items-center justify-center"
                whileHover={{ scale: 1.1, rotate: 180 }}
                transition={{ duration: 0.5 }}
              >
                <span className="text-black text-sm xs:text-base">M</span>
              </motion.div>
              <span className="text-xl xs:text-2xl text-primary tracking-wider">MOS JEWEL</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-foreground hover:text-primary transition-all duration-300 relative group text-sm lg:text-base"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></span>
              </Link>
            ))}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 xs:gap-3 sm:gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:text-primary hover:bg-primary/10 transition-all duration-300 w-8 h-8 xs:w-10 xs:h-10"
              onClick={() => navigate("/search")}
            >
              <Search className="w-4 h-4 xs:w-5 xs:h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:text-primary hover:bg-primary/10 transition-all duration-300 w-8 h-8 xs:w-10 xs:h-10"
              onClick={() => navigate("/wishlist")}
            >
              <Heart className="w-4 h-4 xs:w-5 xs:h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:text-primary hover:bg-primary/10 transition-all duration-300 w-8 h-8 xs:w-10 xs:h-10"
              onClick={() => navigate("/profile")}
            >
              <User className="w-4 h-4 xs:w-5 xs:h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative hover:text-primary hover:bg-primary/10 transition-all duration-300 w-8 h-8 xs:w-10 xs:h-10"
              onClick={onCartClick}
            >
              <ShoppingCart className="w-4 h-4 xs:w-5 xs:h-5" />
              {cartCount > 0 && (
                <motion.span 
                  className="absolute -top-1 -right-1 bg-primary text-black text-xs w-4 h-4 xs:w-5 xs:h-5 rounded-full flex items-center justify-center text-[10px] xs:text-xs"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500 }}
                >
                  {cartCount > 9 ? "9+" : cartCount}
                </motion.span>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-primary/20 bg-black/95 backdrop-blur-md"
          >
            <nav className="container mx-auto px-3 xs:px-4 py-4 xs:py-6 flex flex-col gap-3 xs:gap-4">
              {navLinks.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link
                    to={link.path}
                    className="text-foreground hover:text-primary transition-colors duration-300 block py-2 text-sm xs:text-base"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}