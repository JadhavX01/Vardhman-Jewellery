import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import API from "../../utils/api";
import { useAuth } from "../../context/AuthContext";
import { Mail, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const VerifyOtpPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  // Get email from navigation state or fallback
  const email = location.state?.email || "";

  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [resendLoading, setResendLoading] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!otp || otp.trim() === "") {
      setError("Please enter the OTP");
      return;
    }

    if (otp.length !== 6) {
      setError("OTP must be 6 digits");
      return;
    }

    if (!email) {
      setError("Email is missing. Please register again.");
      return;
    }

    setLoading(true);

    try {
      // Call backend verify-otp endpoint with email and otp
      const res = await API.post("/auth/customer/verify-otp", {
        email: email,  // ✅ CORRECT: backend expects email
        otp: otp,      // ✅ CORRECT: backend expects otp
      });

      if (res.data.token) {
        // Save token and user data using AuthContext
        login({
          token: res.data.token,
          ...res.data, // token, custId, userType
        });

        // Store in localStorage
        localStorage.setItem(
          "vardhaman_user",
          JSON.stringify({
            token: res.data.token,
            custId: res.data.custId,
            email: email,
            userType: res.data.userType,
          })
        );

        toast.success("Email verified successfully!");

        // Navigate to home or dashboard
        setTimeout(() => {
          navigate("/");
        }, 500);
      }
    } catch (err) {
      const errorMsg =
        err.response?.data?.message || "OTP verification failed. Please try again.";
      setError(errorMsg);
      toast.error(errorMsg);
      console.error("OTP verification error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    if (!email) {
      toast.error("Email is missing. Please register again.");
      return;
    }

    setResendLoading(true);
    setResendSuccess(false);

    try {
      const res = await API.post("/auth/resend-otp", {
        email: email,
      });

      setResendSuccess(true);
      toast.success(res.data.message || "OTP resent to your email");
      setOtp(""); // Clear the OTP input
      setError("");

      // Reset success message after 3 seconds
      setTimeout(() => {
        setResendSuccess(false);
      }, 3000);
    } catch (err) {
      const errorMsg =
        err.response?.data?.message || "Failed to resend OTP.";
      toast.error(errorMsg);
      console.error("Resend OTP error:", err);
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-background pt-24 pb-8 px-3 md:px-4 xs:pt-28">
      <div className="bg-card shadow-xl rounded-xl p-4 xs:p-6 md:p-8 w-full max-w-md border-2 border-primary/30 mt-8 xs:mt-12">
        {/* Header */}
        <div className="text-center mb-4 xs:mb-6">
          <div className="w-14 h-14 xs:w-16 xs:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3 xs:mb-4">
            <Mail className="w-6 h-6 xs:w-8 xs:h-8 text-primary" />
          </div>
          <h2 className="text-xl xs:text-2xl font-bold text-foreground">
            Verify Your Email
          </h2>
          <p className="text-muted-foreground text-xs xs:text-sm mt-1 xs:mt-2">
            Enter the 6-digit code sent to
          </p>
          <p className="text-foreground font-medium text-sm xs:text-base">
            {email || "your email"}
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-destructive/10 text-destructive p-3 rounded-lg mb-4 text-xs xs:text-sm border border-destructive/50 font-medium">
            {error}
          </div>
        )}

        {/* Resend Success Message */}
        {resendSuccess && (
          <div className="bg-green-500/10 text-green-600 p-3 rounded-lg mb-4 text-xs xs:text-sm border border-green-500/50 font-medium">
            OTP resent successfully! Check your email.
          </div>
        )}

        {/* OTP Form */}
        <form onSubmit={handleSubmit} className="space-y-4 xs:space-y-5">
          <div>
            <label className="block text-xs xs:text-sm font-semibold mb-2 text-foreground">
              Enter OTP *
            </label>
            <input
              type="text"
              value={otp}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, "").slice(0, 6);
                setOtp(value);
              }}
              className="w-full border-2 border-input bg-background rounded-lg px-3 xs:px-4 py-2 xs:py-3 text-xl xs:text-2xl text-center tracking-widest font-medium focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
              placeholder="000000"
              maxLength="6"
              required
              disabled={loading}
            />
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Enter 6-digit code from your email
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-primary to-primary/90 text-primary-foreground py-2 xs:py-3 rounded-lg hover:from-primary/90 hover:to-primary transition-all duration-300 disabled:from-muted disabled:to-muted disabled:text-muted-foreground font-bold text-sm xs:text-base shadow-lg hover:shadow-xl disabled:hover:shadow-lg"
          >
            {loading ? "Verifying..." : "Verify OTP"}
          </button>
        </form>

        {/* Resend OTP Section */}
        <div className="mt-4 xs:mt-6 pt-4 xs:pt-6 border-t border-border">
          <p className="text-center text-xs xs:text-sm text-muted-foreground mb-2 xs:mb-3">
            Didn't receive the code?
          </p>
          <button
            onClick={handleResendOTP}
            disabled={resendLoading}
            className="w-full border-2 border-primary text-primary py-2 xs:py-3 rounded-lg hover:bg-primary/5 transition-all duration-300 disabled:bg-muted disabled:text-muted-foreground disabled:border-muted font-medium text-sm xs:text-base"
          >
            {resendLoading ? "Sending..." : "Resend OTP"}
          </button>
        </div>

        {/* Back Link */}
        <div className="mt-4 xs:mt-6 text-center">
          <Link
            to="/register"
            className="inline-flex items-center gap-2 text-xs xs:text-sm text-muted-foreground hover:text-primary transition-colors duration-300"
          >
            <ArrowLeft className="w-3 h-3 xs:w-4 xs:h-4" />
            Back to Registration
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VerifyOtpPage;