import { motion } from "motion/react";
import { ProductCard } from "../shared/ProductCard";
import { Product } from "../../types/Product";
import { allProducts } from "../../data/products";
import { useState } from "react";
import { Search, X } from "lucide-react";
import { Button } from "../ui/button";

interface SearchPageProps {
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: (productId: number) => boolean;
}

export function SearchPage({ onAddToCart, onQuickView, onToggleWishlist, isInWishlist }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProducts = allProducts.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-20">
      {/* Search Header */}
      <section className="bg-gradient-to-b from-secondary/30 to-background py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl mb-6">
              Search <span className="text-primary">Collection</span>
            </h1>
            <p className="text-muted-foreground mb-8">
              Find your perfect piece from our extensive collection
            </p>

            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for jewelry..."
                className="w-full pl-12 pr-12 py-4 bg-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-lg"
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 hover:bg-primary/10 hover:text-primary"
                  onClick={() => setSearchQuery("")}
                >
                  <X className="w-5 h-5" />
                </Button>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Results */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-8"
        >
          <p className="text-muted-foreground">
            {searchQuery ? (
              <>
                Found <span className="text-primary">{filteredProducts.length}</span> {filteredProducts.length === 1 ? 'result' : 'results'} for "<span className="text-foreground">{searchQuery}</span>"
              </>
            ) : (
              <>
                Showing all <span className="text-primary">{allProducts.length}</span> products
              </>
            )}
          </p>
        </motion.div>

        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
                onToggleWishlist={onToggleWishlist}
                isInWishlist={isInWishlist(product.id)}
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-12 h-12 text-primary" />
            </div>
            <h3 className="text-2xl mb-4">No results found</h3>
            <p className="text-muted-foreground mb-6">
              We couldn't find any products matching "{searchQuery}"
            </p>
            <Button
              onClick={() => setSearchQuery("")}
              className="bg-primary text-black hover:bg-primary/90"
            >
              Clear Search
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
