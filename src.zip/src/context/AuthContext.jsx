import { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load token from localStorage when app starts
  useEffect(() => {
    const storedUser = localStorage.getItem("vardhaman_user");
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (err) {
        console.error("Error parsing stored user:", err);
        localStorage.removeItem("vardhaman_user");
      }
    }
    setLoading(false);
  }, []);

  // Save user in localStorage when logged in
  const login = (userData) => {
    localStorage.setItem("vardhaman_user", JSON.stringify(userData));
    setUser(userData);
  };

  // Logout — clear user + localStorage
  const logout = () => {
    localStorage.removeItem("vardhaman_user");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// custom hook for easy access
export const useAuth = () => useContext(AuthContext);