import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../../utils/api";
import { toast } from "sonner";

const RegisterPage = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    custName: "",
    email: "",
    mobile: "",
    add1: "",
    add2: "",
    state: "",
    cityName: "",
    pinCode: "",
    password: "",
    confirmPassword: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [passwordStrength, setPasswordStrength] = useState("");

  const [states, setStates] = useState([]);
  const [availableCities, setAvailableCities] = useState([]);
  const [citiesCache, setCitiesCache] = useState({});
  const [citySearch, setCitySearch] = useState("");
  const [showCityDropdown, setShowCityDropdown] = useState(false);

  const cityDropdownRef = useRef(null);
  const cityInputRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        cityDropdownRef.current &&
        !cityDropdownRef.current.contains(event.target) &&
        cityInputRef.current &&
        !cityInputRef.current.contains(event.target)
      ) {
        setShowCityDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const fetchStates = async () => {
      try {
        const res = await fetch(
          "https://countriesnow.space/api/v0.1/countries/states",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ country: "India" }),
          }
        );
        const data = await res.json();
        if (data?.data?.states) {
          setStates(data.data.states.map((s) => s.name));
        }
      } catch (err) {
        console.error("Error loading states:", err);
        toast.error("Failed to load states. Please refresh.");
      }
    };
    fetchStates();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "mobile") {
      let val = value.replace(/[^\d+]/g, "");
      if (val.startsWith("+91")) val = "+91" + val.slice(3, 13);
      else val = val.slice(0, 10);
      setForm({ ...form, mobile: val });
      return;
    }

    if (name === "pinCode") {
      const val = value.replace(/\D/g, "").slice(0, 6);
      setForm({ ...form, pinCode: val });
      return;
    }

    if (name === "password") {
      setForm({ ...form, password: value });
      if (!value) setPasswordStrength("");
      else if (value.length < 6) setPasswordStrength("Too Short");
      else if (!/(?=.*[a-z])/.test(value)) setPasswordStrength("Add lowercase");
      else if (!/(?=.*[A-Z])/.test(value)) setPasswordStrength("Add uppercase");
      else if (!/(?=.*\d)/.test(value)) setPasswordStrength("Add number");
      else if (!/(?=.*[!@_#\$%\^&\*])/.test(value)) setPasswordStrength("Add special char");
      else setPasswordStrength("Strong");
      return;
    }

    setForm({ ...form, [name]: value });
  };

  const handleStateChange = async (e) => {
    const selectedState = e.target.value;
    setForm({ ...form, state: selectedState, cityName: "" });
    setCitySearch("");
    setShowCityDropdown(false);
    setAvailableCities([]);

    if (!selectedState) return;

    if (citiesCache[selectedState]) {
      setAvailableCities(citiesCache[selectedState]);
      return;
    }

    try {
      const res = await fetch(
        "https://countriesnow.space/api/v0.1/countries/state/cities",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ country: "India", state: selectedState }),
        }
      );
      const data = await res.json();
      if (data?.data) {
        setAvailableCities(data.data);
        setCitiesCache((prev) => ({ ...prev, [selectedState]: data.data }));
      }
    } catch (err) {
      console.error("Error loading cities:", err);
      toast.error("Failed to load cities for this state.");
    }
  };

  const handleCitySearch = (e) => {
    const search = e.target.value;
    setCitySearch(search);
    if (form.state && availableCities.length > 0) setShowCityDropdown(true);
    if (form.cityName && search !== form.cityName) setForm({ ...form, cityName: "" });
  };

  const handleCitySelect = (city) => {
    setForm({ ...form, cityName: city });
    setCitySearch("");
    setShowCityDropdown(false);
  };

  const getFilteredCities = () => {
    if (!form.state) return [];
    const cities = availableCities || [];
    if (!citySearch) return cities.slice(0, 10);
    return cities
      .filter((c) => c.toLowerCase().includes(citySearch.toLowerCase()))
      .slice(0, 15);
  };

  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@_#\$%\^&\*])[A-Za-z\d!@_#\$%\^&\*]{6,}$/;

  const validateForm = () => {
    if (!form.custName.trim()) return setError("Customer name is required");
    if (!form.email.includes("@")) return setError("Valid email is required");
    if (!form.mobile || !/^(\+91)?\d{10}$/.test(form.mobile))
      return setError("Valid mobile number is required (10 digits, optional +91)");
    if (!form.add1.trim()) return setError("Address Line 1 is required");
    if (!form.state) return setError("State is required");
    if (!form.cityName.trim()) return setError("City is required");
    if (!form.pinCode || !/^\d{6}$/.test(form.pinCode))
      return setError("Valid pincode (6 digits) is required");
    if (!form.password || !passwordRegex.test(form.password))
      return setError(
        "Password must be at least 6 chars, include uppercase, lowercase, number & special char"
      );
    if (form.password !== form.confirmPassword) return setError("Passwords do not match");
    setError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    try {
      const res = await API.post("/auth/customer/register", form);
      if (res.data.custId) {
        toast.success("Registration successful! Check your email for OTP.");
        navigate("/verify-otp", {
          state: { email: form.email, custId: res.data.custId },
        });
      }
    } catch (err) {
      const errorMsg =
        err.response?.data?.message || "Registration failed. Please try again.";
      setError(errorMsg);
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const filteredCities = getFilteredCities();

  return (
    <div className="flex items-center justify-center min-h-screen bg-background py-8 px-3 md:px-4">
      <div className="bg-card shadow-xl rounded-xl p-6 md:p-8 w-full max-w-2xl border border-border">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10 text-foreground">
          Create Account
        </h2>

        {error && (
          <div className="bg-destructive/10 text-destructive p-4 rounded-lg mb-6 text-sm border border-destructive/50">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information Section */}
          <div className="bg-muted p-4 md:p-6 rounded-lg border border-border">
            <h3 className="text-lg md:text-xl font-semibold mb-4 text-foreground border-b pb-2 border-border">
              Personal Information
            </h3>

            <div className="space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="custName"
                  value={form.custName}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Enter your full name"
                  required
                  disabled={loading}
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Enter your email"
                  required
                  disabled={loading}
                />
              </div>

              {/* Mobile */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Mobile Number *
                </label>
                <input
                  type="tel"
                  name="mobile"
                  value={form.mobile}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Enter 10-digit mobile number"
                  required
                  disabled={loading}
                />
              </div>
            </div>
          </div>

          {/* Address Section */}
          <div className="bg-muted p-4 md:p-6 rounded-lg border border-border">
            <h3 className="text-lg md:text-xl font-semibold mb-4 text-foreground border-b pb-2 border-border">
              Address Details
            </h3>

            <div className="space-y-4">
              {/* Address Line 1 */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Address Line 1 *
                </label>
                <input
                  type="text"
                  name="add1"
                  value={form.add1}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Street address, P.O. Box, Company name"
                  required
                  disabled={loading}
                />
              </div>

              {/* Address Line 2 */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Address Line 2 (Optional)
                </label>
                <input
                  type="text"
                  name="add2"
                  value={form.add2}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Apartment, suite, unit, building, floor, etc."
                  disabled={loading}
                />
              </div>

              {/* State + City */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* State */}
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    State *
                  </label>
                  <select
                    name="state"
                    value={form.state}
                    onChange={handleStateChange}
                    className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                    required
                    disabled={loading}
                  >
                    <option value="">Select State</option>
                    {states.map((state) => (
                      <option key={state} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>

                {/* City */}
                <div className="relative">
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    City *
                  </label>
                  <input
                    ref={cityInputRef}
                    type="text"
                    value={citySearch || form.cityName}
                    onChange={handleCitySearch}
                    onFocus={() => {
                      if (form.state && availableCities.length > 0) {
                        setShowCityDropdown(true);
                      }
                    }}
                    className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                    placeholder={form.state ? "Search or select city" : "Select state first"}
                    disabled={!form.state || loading}
                  />

                  {/* Dropdown */}
                  {showCityDropdown && form.state && (
                    <div 
                      ref={cityDropdownRef}
                      className="absolute top-full left-0 right-0 z-50 mt-1"
                    >
                      <div className="bg-card border-2 border-primary/50 rounded-lg shadow-2xl max-h-60 overflow-y-auto">
                        {filteredCities.length > 0 ? (
                          filteredCities.map((city, index) => (
                            <button
                              key={`${city}-${index}`}
                              type="button"
                              onClick={() => handleCitySelect(city)}
                              className="w-full text-left px-4 py-3 hover:bg-primary hover:text-primary-foreground text-foreground font-medium border-b border-border last:border-b-0 transition-colors duration-200"
                            >
                              {city}
                            </button>
                          ))
                        ) : (
                          <div className="px-4 py-3 text-muted-foreground text-sm border-b border-border">
                            {citySearch ? `No cities found for "${citySearch}"` : "No cities available"}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Selected City Indicator */}
                  {form.cityName && !citySearch && (
                    <div className="text-sm text-green-500 font-medium mt-2 flex items-center">
                      <span className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center text-white text-xs mr-2">✓</span>
                      Selected: {form.cityName}
                    </div>
                  )}
                </div>
              </div>

              {/* Pincode - REMOVED DUPLICATE, KEPT ONLY ONE */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Pincode *
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  name="pinCode"
                  value={form.pinCode}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Enter 6-digit pincode"
                  maxLength="6"
                  required
                  disabled={loading}
                />
              </div>
            </div>
          </div>

          {/* Password Section */}
          <div className="bg-muted p-4 md:p-6 rounded-lg border border-border">
            <h3 className="text-lg md:text-xl font-semibold mb-4 text-foreground border-b pb-2 border-border">
              Security
            </h3>

            <div className="space-y-4">
              {/* Password */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Password *
                </label>
                <input
                  type="password"
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  className={`w-full border-2 ${
                    passwordStrength === "Strong"
                      ? "border-green-500"
                      : passwordStrength && passwordStrength !== "Strong"
                      ? "border-red-500"
                      : "border-input"
                  } text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium`}
                  placeholder="Enter password (min 6 chars, uppercase, lowercase, number, special)"
                  required
                  disabled={loading}
                />
                {passwordStrength && (
                  <p
                    className={`mt-1 text-sm font-medium ${
                      passwordStrength === "Strong"
                        ? "text-green-500"
                        : "text-red-500"
                    }`}
                  >
                    {passwordStrength}
                  </p>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-sm font-semibold mb-2 text-foreground">
                  Confirm Password *
                </label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  className="w-full border-2 border-input text-foreground bg-background rounded-lg px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                  placeholder="Confirm password"
                  required
                  disabled={loading}
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-primary to-primary/90 text-primary-foreground py-4 rounded-xl hover:from-primary/90 hover:to-primary transition-all duration-300 disabled:from-muted disabled:to-muted disabled:text-muted-foreground font-bold text-lg shadow-lg hover:shadow-xl disabled:hover:shadow-lg mt-2"
          >
            {loading ? "Creating Account..." : "Create Account"}
          </button>

          {/* Login Link */}
          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link
              to="/login"
              className="text-primary hover:underline font-semibold"
            >
              Login here
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;