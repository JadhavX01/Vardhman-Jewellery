import { motion } from "motion/react";
import { ProductCard } from "../shared/ProductCard";
import { Product } from "../../types/Product";
import { allProducts } from "../../data/products";

interface NecklacesPageProps {
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: (productId: number) => boolean;
}

export function NecklacesPage({ onAddToCart, onQuickView, onToggleWishlist, isInWishlist }: NecklacesPageProps) {
  const necklaces = allProducts.filter(p => p.category === "Necklaces");

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Banner */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=1920&q=80')`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/90" />
        <motion.div 
          className="relative z-10 text-center container mx-auto px-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <motion.div
            className="inline-block mb-4"
            animate={{ 
              boxShadow: [
                "0 0 20px rgba(212, 175, 55, 0.3)",
                "0 0 40px rgba(212, 175, 55, 0.5)",
                "0 0 20px rgba(212, 175, 55, 0.3)",
              ]
            }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <span className="px-6 py-2 bg-primary/10 border border-primary/30 text-primary text-sm uppercase tracking-widest rounded-full backdrop-blur-sm">
              Necklaces Collection
            </span>
          </motion.div>
          <h1 className="text-5xl md:text-6xl mb-4">
            Stunning <span className="text-primary">Necklaces</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Elegant necklaces that add a touch of sophistication to any outfit
          </p>
        </motion.div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <p className="text-muted-foreground">
            Showing {necklaces.length} {necklaces.length === 1 ? 'necklace' : 'necklaces'}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {necklaces.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onQuickView={onQuickView}
              onToggleWishlist={onToggleWishlist}
              isInWishlist={isInWishlist(product.id)}
            />
          ))}
        </div>

        {necklaces.length === 0 && (
          <motion.div 
            className="text-center py-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <p className="text-xl text-muted-foreground">No necklaces available at the moment.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
