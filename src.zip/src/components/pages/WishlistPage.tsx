import { motion } from "motion/react";
import { ProductCard } from "../shared/ProductCard";
import { Product } from "../../types/Product";
import { Heart } from "lucide-react";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";

interface WishlistPageProps {
  wishlistItems: Product[];
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
}

export function WishlistPage({ wishlistItems, onAddToCart, onQuickView, onToggleWishlist }: WishlistPageProps) {
  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="bg-gradient-to-b from-secondary/30 to-background py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-8 h-8 text-primary fill-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl mb-4">
              Your <span className="text-primary">Wishlist</span>
            </h1>
            <p className="text-muted-foreground text-lg">
              {wishlistItems.length} {wishlistItems.length === 1 ? 'item' : 'items'} saved for later
            </p>
          </motion.div>
        </div>
      </section>

      {/* Wishlist Items */}
      <div className="container mx-auto px-4 py-12">
        {wishlistItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {wishlistItems.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
                onToggleWishlist={onToggleWishlist}
                isInWishlist={true}
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-12 h-12 text-primary" />
            </div>
            <h3 className="text-2xl mb-4">Your wishlist is empty</h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Start adding items to your wishlist by clicking the heart icon on products you love
            </p>
            <Link to="/collections">
              <Button className="bg-primary text-black hover:bg-primary/90">
                Explore Products
              </Button>
            </Link>
          </motion.div>
        )}
      </div>
    </div>
  );
}
