// frontend/src/utils/api.js
import axios from "axios";

const API = axios.create({
  baseURL: "http://192.168.1.37:5000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor - attach token to every request
API.interceptors.request.use(
  (config) => {
    const storedUser = localStorage.getItem("vardhaman_user");
    if (storedUser) {
      try {
        const { token } = JSON.parse(storedUser);
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      } catch (err) {
        console.error("Error parsing stored user:", err);
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - handle auth errors
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem("vardhaman_user");
      
      // Only redirect if not already on login page
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default API;