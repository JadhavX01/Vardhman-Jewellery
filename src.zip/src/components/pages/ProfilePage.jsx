import { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import API from "../../utils/api";
import { User, Package, Heart, Settings, LogOut, MapPin, CreditCard, Mail, Phone } from "lucide-react";
import { Button } from "../ui/button";
import { toast } from "sonner";

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [safeUserData, setSafeUserData] = useState({
    name: "Demo User",
    email: "demo@gmail.com",
    mobile: "9999999999",
    role: "user",
  });

  const [activeTab, setActiveTab] = useState("profile");
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({ firstName: "", lastName: "" });

  // Load user data
  useEffect(() => {
    try {
      const stored = localStorage.getItem("vardhaman_user");
      const parsed = stored ? JSON.parse(stored) : null;
      const authUser = user || parsed;

      if (authUser) {
        const userData = {
          name: authUser.name || authUser.userName || authUser.Login || "Demo User",
          email: authUser.email || authUser.Login || "demo@gmail.com",
          mobile: authUser.mobile || authUser.phone || "9999999999",
          role: authUser.role || "user",
        };
        
        setSafeUserData(userData);

        // Set form data
        const parts = userData.name.split(" ");
        setFormData({
          firstName: parts[0] || "Demo",
          lastName: parts.slice(1).join(" ") || "User",
        });
      }
    } catch (err) {
      console.error("Error reading user data:", err);
    }
  }, [user]);

  const getInitials = (name) => {
    if (!name || typeof name !== "string") return "DU";
    const parts = name.trim().split(" ");
    return parts.map((p) => p[0]).join("").toUpperCase().slice(0, 2);
  };

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "orders", label: "Orders", icon: Package },
    { id: "wishlist", label: "Wishlist", icon: Heart },
    { id: "addresses", label: "Addresses", icon: MapPin },
    { id: "payment", label: "Payment Methods", icon: CreditCard },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const handleSaveChanges = async () => {
    setIsLoading(true);
    try {
      const fullName = `${formData.firstName} ${formData.lastName}`.trim();
      
      const res = await API.put("/auth/update-profile", {
        name: fullName,
        email: safeUserData.email,
        mobile: safeUserData.mobile,
      });

      if (res.data) {
        // Update local state
        setSafeUserData((prev) => ({ ...prev, name: fullName }));
        
        // Update localStorage
        const stored = localStorage.getItem("vardhaman_user");
        if (stored) {
          const parsed = JSON.parse(stored);
          parsed.name = fullName;
          localStorage.setItem("vardhaman_user", JSON.stringify(parsed));
        }

        toast.success("Profile updated successfully!");
      }
    } catch (error) {
      console.error("Save changes error:", error);
      toast.error(error.response?.data?.message || "Failed to update profile");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await API.post("/auth/logout");
    } catch (error) {
      console.error("Backend logout failed:", error);
    } finally {
      logout();
      localStorage.removeItem("vardhaman_user");
      navigate("/login");
    }
  };

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl mb-2">
            My <span className="text-blue-600">Account</span>
          </h1>
          <p className="text-gray-600 mb-8">Manage your account and preferences</p>

          <div className="grid lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1">
              <div className="bg-white border rounded-xl p-6 shadow-sm sticky top-24">
                <div className="text-center mb-6 pb-6 border-b">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-700 font-semibold text-xl">
                    {getInitials(safeUserData.name)}
                  </div>
                  <h3 className="text-lg mb-1">{safeUserData.name}</h3>
                  <p className="text-sm text-gray-500">{safeUserData.email}</p>
                  <div className="mt-2">
                    <span className="px-2 py-1 bg-blue-50 text-blue-600 text-xs rounded">
                      {safeUserData.role === "admin" ? "Admin" : "Premium Member"}
                    </span>
                  </div>
                </div>

                <nav className="space-y-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                        activeTab === tab.id
                          ? "bg-blue-100 text-blue-700 border border-blue-200"
                          : "hover:bg-gray-100 text-gray-700"
                      }`}
                    >
                      <tab.icon className="w-5 h-5" />
                      <span className="text-sm">{tab.label}</span>
                    </button>
                  ))}
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-red-50 text-red-600 transition-all duration-300"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="text-sm">Logout</span>
                  </button>
                </nav>
              </div>
            </div>

            <div className="lg:col-span-3 space-y-8">
              {activeTab === "profile" && (
                <div className="bg-white border rounded-xl p-8 shadow-sm">
                  <h2 className="text-2xl mb-6">Personal Information</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm text-gray-500 mb-2">First Name</label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        className="w-full px-4 py-3 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-500 mb-2">Last Name</label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        className="w-full px-4 py-3 border rounded-lg"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm text-gray-500 mb-2">Email</label>
                      <div className="flex items-center gap-3 w-full px-4 py-3 border rounded-lg bg-gray-50">
                        <Mail className="w-4 h-4 text-gray-500" />
                        <span>{safeUserData.email}</span>
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm text-gray-500 mb-2">Phone</label>
                      <div className="flex items-center gap-3 w-full px-4 py-3 border rounded-lg bg-gray-50">
                        <Phone className="w-4 h-4 text-gray-500" />
                        <span>{safeUserData.mobile}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex gap-4">
                    <Button 
                      onClick={handleSaveChanges}
                      disabled={isLoading}
                      className="bg-blue-600 text-white hover:bg-blue-700"
                    >
                      {isLoading ? "Saving..." : "Save Changes"}
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        const parts = safeUserData.name.split(" ");
                        setFormData({
                          firstName: parts[0] || "Demo",
                          lastName: parts.slice(1).join(" ") || "User",
                        });
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}