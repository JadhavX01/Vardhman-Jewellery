// import { X, ShoppingCart, Heart } from "lucide-react";
// import { Button } from "../components/ui/button";
// import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
// import { useApp } from "../context/AppContext";
// import { ImageWithFallback } from "../components/figma/ImageWithFallback";
// import { Badge } from "../components/ui/badge";

// export function ProductQuickView({ product, isOpen, onClose }) {
//   const { addToCart, addToWishlist, isInWishlist } = useApp();

//   if (!product) return null;

//   const inWishlist = isInWishlist(product.id);

//   const handleAddToCart = () => {
//     addToCart(product);
//   };

//   const handleWishlistToggle = () => {
//     if (inWishlist) {
//       // User would need removeFromWishlist from context
//     } else {
//       addToWishlist(product);
//     }
//   };

//   return (
//     <Dialog open={isOpen} onOpenChange={onClose}>
//       <DialogContent className="max-w-4xl bg-card">
//         <DialogHeader>
//           <DialogTitle className="text-2xl text-primary">Quick View</DialogTitle>
//         </DialogHeader>
        
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
//           {/* Image */}
//           <div className="aspect-square rounded-lg overflow-hidden bg-secondary">
//             <ImageWithFallback
//               src={product.image}
//               alt={product.name}
//               className="w-full h-full object-cover"
//             />
//           </div>

//           {/* Details */}
//           <div className="flex flex-col">
//             <Badge className="w-fit mb-2 bg-primary text-primary-foreground">
//               {product.category}
//             </Badge>
//             <h2 className="text-2xl mb-2">{product.name}</h2>
//             <div className="flex items-center gap-2 mb-4">
//               <div className="flex items-center gap-1">
//                 {[...Array(5)].map((_, i) => (
//                   <span
//                     key={i}
//                     className={`text-sm ${
//                       i < (product.rating || 5) ? "text-primary" : "text-muted-foreground"
//                     }`}
//                   >
//                     ★
//                   </span>
//                 ))}
//               </div>
//               <span className="text-sm text-muted-foreground">
//                 ({product.rating || 5}.0)
//               </span>
//             </div>

//             <p className="text-3xl text-primary font-semibold mb-4">
//               ${product.price.toLocaleString()}
//             </p>

//             <p className="text-sm text-muted-foreground mb-6">
//               {product.description}
//             </p>

//             {product.material && (
//               <div className="mb-6">
//                 <h4 className="text-sm font-semibold mb-2">Material</h4>
//                 <Badge variant="outline">{product.material}</Badge>
//               </div>
//             )}

//             {product.inStock && (
//               <div className="mb-6">
//                 <Badge className="bg-green-500/20 text-green-500 hover:bg-green-500/30">
//                   ✓ In Stock
//                 </Badge>
//               </div>
//             )}

//             <div className="flex gap-3 mt-auto">
//               <Button
//                 onClick={handleAddToCart}
//                 className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
//               >
//                 <ShoppingCart className="h-4 w-4 mr-2" />
//                 Add to Cart
//               </Button>
//               <Button
//                 variant="outline"
//                 size="icon"
//                 onClick={handleWishlistToggle}
//                 className={inWishlist ? "border-primary" : ""}
//               >
//                 <Heart
//                   className={`h-4 w-4 ${inWishlist ? "fill-primary text-primary" : ""}`}
//                 />
//               </Button>
//             </div>
//           </div>
//         </div>
//       </DialogContent>
//     </Dialog>
//   );
// }
