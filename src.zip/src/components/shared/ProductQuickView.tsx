import { motion, AnimatePresence } from "motion/react";
import { X, ShoppingCart, Heart, Star } from "lucide-react";
import { Button } from "../ui/button";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Product } from "../../types/Product";
import { useState } from "react";

interface ProductQuickViewProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export function ProductQuickView({ product, isOpen, onClose, onAddToCart }: ProductQuickViewProps) {
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-card border border-primary/20 rounded-2xl overflow-hidden max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl shadow-primary/30"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="grid md:grid-cols-2 gap-8 p-8">
                {/* Image */}
                <div className="relative aspect-square rounded-xl overflow-hidden bg-secondary group">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm hover:bg-primary hover:text-black transition-all duration-300"
                    onClick={onClose}
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                {/* Details */}
                <div className="flex flex-col">
                  <div className="flex-1">
                    <motion.div 
                      className="inline-block px-3 py-1 bg-primary/10 border border-primary/20 text-primary text-xs uppercase tracking-wider rounded-full mb-4"
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                    >
                      {product.category}
                    </motion.div>

                    <motion.h2 
                      className="text-3xl text-foreground mb-4"
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.1 }}
                    >
                      {product.name}
                    </motion.h2>

                    <div className="flex items-center gap-2 mb-6">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < 4 ? "fill-primary text-primary" : "fill-muted text-muted"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">(124 reviews)</span>
                    </div>

                    <motion.div 
                      className="text-4xl text-primary mb-6"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                    >
                      ${product.price.toLocaleString()}
                    </motion.div>

                    <p className="text-muted-foreground mb-8 leading-relaxed">
                      {product.description}
                    </p>

                    <div className="space-y-6 mb-8">
                      <div>
                        <h3 className="text-sm uppercase tracking-wider mb-3">Material</h3>
                        <div className="flex gap-2 flex-wrap">
                          {["18K Gold", "14K Gold", "Platinum"].map((material) => (
                            <Button
                              key={material}
                              variant="outline"
                              size="sm"
                              className="border-primary/50 hover:bg-primary hover:text-black transition-all duration-300"
                            >
                              {material}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm uppercase tracking-wider mb-3">Size</h3>
                        <div className="flex gap-2">
                          {["S", "M", "L"].map((size) => (
                            <Button
                              key={size}
                              variant="outline"
                              size="sm"
                              className="border-primary/50 hover:bg-primary hover:text-black w-12 transition-all duration-300"
                            >
                              {size}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center border border-border rounded-lg">
                        <button
                          className="px-4 py-3 hover:bg-primary/10 hover:text-primary transition-all duration-300"
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        >
                          -
                        </button>
                        <span className="px-6 py-3 border-x border-border">{quantity}</span>
                        <button
                          className="px-4 py-3 hover:bg-primary/10 hover:text-primary transition-all duration-300"
                          onClick={() => setQuantity(quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        className="border-primary/50 hover:bg-primary hover:text-black h-[52px] w-[52px] transition-all duration-300"
                      >
                        <Heart className="w-5 h-5" />
                      </Button>
                    </div>

                    <Button
                      size="lg"
                      className="w-full bg-primary text-black hover:bg-primary/90 transition-all duration-300 hover:scale-105"
                      onClick={() => {
                        onAddToCart(product);
                        onClose();
                      }}
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
