import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../../utils/api";
import { useAuth } from "../../context/AuthContext";
import { toast } from "sonner";

const LoginPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    if (!form.email || form.email.trim() === "") {
      setError("Email is required");
      setLoading(false);
      return;
    }

    if (!form.password || form.password.trim() === "") {
      setError("Password is required");
      setLoading(false);
      return;
    }

    try {
      const res = await API.post("/auth/customer/login", {
        email: form.email,
        password: form.password,
      });

      if (res.data.token) {
        login({
          token: res.data.token,
          ...res.data.user,
        });

        localStorage.setItem(
          "vardhaman_user",
          JSON.stringify({
            token: res.data.token,
            ...res.data.user,
          })
        );

        toast.success("Login successful!");

        setTimeout(() => {
          navigate("/");
        }, 500);
      }
    } catch (err) {
      const errorMsg =
        err.response?.data?.message || "Login failed. Please check your credentials.";
      setError(errorMsg);
      toast.error(errorMsg);
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-background pt-24 pb-8 px-3 md:px-4 xs:pt-28">
      <div className="bg-card shadow-xl rounded-xl p-4 xs:p-6 md:p-8 w-full max-w-md border-2 border-primary/30 mt-8 xs:mt-12">
        <div className="mb-1">
          <h2 className="text-xl xs:text-2xl md:text-3xl font-bold text-center mb-2 text-foreground">
            Welcome Back
          </h2>
          <p className="text-center text-muted-foreground text-xs xs:text-sm">
            Login to your account to continue shopping
          </p>
        </div>

        {error && (
          <div className="bg-destructive/10 text-destructive p-3 xs:p-4 rounded-lg mb-4 xs:mb-6 text-xs xs:text-sm border border-destructive/50 font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 xs:space-y-5">
          {/* Email Field */}
          <div>
            <label className="block text-xs xs:text-sm font-semibold mb-2 text-foreground">
              Email Address *
            </label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="w-full border-2 border-input text-foreground bg-background rounded-lg px-3 xs:px-4 py-2 xs:py-3 text-sm xs:text-base focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
              placeholder="Enter your email"
              required
              disabled={loading}
            />
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-xs xs:text-sm font-semibold mb-2 text-foreground">
              Password *
            </label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              className="w-full border-2 border-input text-foreground bg-background rounded-lg px-3 xs:px-4 py-2 xs:py-3 text-sm xs:text-base focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
              placeholder="Enter your password"
              required
              disabled={loading}
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-primary to-primary/90 text-primary-foreground py-2 xs:py-3 rounded-lg hover:from-primary/90 hover:to-primary transition-all duration-300 disabled:from-muted disabled:to-muted disabled:text-muted-foreground font-bold text-sm xs:text-base shadow-lg hover:shadow-xl disabled:hover:shadow-lg mt-4 xs:mt-6"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        {/* Forgot Password & Register Links */}
        <div className="mt-4 xs:mt-6 pt-4 xs:pt-6 border-t border-border space-y-2 xs:space-y-3">
          <div className="text-center">
            <Link to="/forgot-password" className="text-primary hover:text-primary/80 text-xs xs:text-sm font-medium transition-colors">
              Forgot Password?
            </Link>
          </div>
          <div className="text-center text-muted-foreground text-xs xs:text-sm">
            Don't have an account?{" "}
            <Link to="/register" className="text-primary hover:text-primary/80 font-semibold transition-colors">
              Register here
            </Link>
          </div>
        </div>

        {/* Staff/Admin Login Section */}
        <div className="mt-4 xs:mt-6 pt-4 xs:pt-6 border-t border-border">
          <p className="text-center text-xs text-muted-foreground mb-3 xs:mb-4 font-medium">
            Staff or Admin?
          </p>
          <Link
            to="/staff-login"
            className="block w-full border-2 border-primary/50 text-primary py-2 xs:py-3 rounded-lg hover:bg-primary/5 transition font-semibold text-center text-xs xs:text-sm"
          >
            Staff/Admin Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;