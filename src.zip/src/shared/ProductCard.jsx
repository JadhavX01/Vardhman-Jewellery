// import { ShoppingCart, Heart, Eye } from "lucide-react";
// import { Button } from "../components/ui/button";
// import { Badge } from "../components/ui/badge";
// import { useApp } from "../context/AppContext";
// import { motion } from "motion/react";
// import { ImageWithFallback } from "../components/figma/ImageWithFallback";
// import { useState } from "react";

// export function ProductCard({ product, onQuickView }) {
//   const { addToCart, addToWishlist, removeFromWishlist, isInWishlist } = useApp();
//   const [imageLoaded, setImageLoaded] = useState(false);
//   const inWishlist = isInWishlist(product.id);

//   const handleWishlistClick = (e) => {
//     e.preventDefault();
//     if (inWishlist) {
//       removeFromWishlist(product.id);
//     } else {
//       addToWishlist(product);
//     }
//   };

//   const handleAddToCart = (e) => {
//     e.preventDefault();
//     addToCart(product);
//   };

//   const handleQuickView = (e) => {
//     e.preventDefault();
//     if (onQuickView) {
//       onQuickView(product);
//     }
//   };

//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 20 }}
//       animate={{ opacity: 1, y: 0 }}
//       whileHover={{ y: -8 }}
//       transition={{ duration: 0.3 }}
//       className="group relative bg-card rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all duration-300 shadow-lg hover:shadow-2xl hover:shadow-primary/20"
//     >
//       {/* Image Container */}
//       <div className="relative aspect-square overflow-hidden bg-secondary">
//         <ImageWithFallback
//           src={product.image}
//           alt={product.name}
//           className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-110 ${
//             imageLoaded ? "opacity-100" : "opacity-0"
//           }`}
//           onLoad={() => setImageLoaded(true)}
//         />
        
//         {/* Overlay on Hover */}
//         <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
//           <Button
//             size="icon"
//             variant="secondary"
//             className="bg-white/90 hover:bg-white text-black"
//             onClick={handleQuickView}
//           >
//             <Eye className="h-4 w-4" />
//           </Button>
//           <Button
//             size="icon"
//             variant="secondary"
//             className={`${
//               inWishlist
//                 ? "bg-primary text-primary-foreground"
//                 : "bg-white/90 hover:bg-white text-black"
//             }`}
//             onClick={handleWishlistClick}
//           >
//             <Heart className={`h-4 w-4 ${inWishlist ? "fill-current" : ""}`} />
//           </Button>
//         </div>

//         {/* Stock Badge */}
//         {product.inStock && (
//           <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
//             In Stock
//           </Badge>
//         )}
//       </div>

//       {/* Product Info */}
//       <div className="p-4">
//         <p className="text-xs text-muted-foreground mb-1">{product.category}</p>
//         <h3 className="text-base mb-2 line-clamp-1 group-hover:text-primary transition-colors">
//           {product.name}
//         </h3>
        
//         <div className="flex items-center justify-between mb-3">
//           <span className="text-lg text-primary font-semibold">
//             ${product.price.toLocaleString()}
//           </span>
//           {product.rating && (
//             <div className="flex items-center gap-1">
//               {[...Array(5)].map((_, i) => (
//                 <span
//                   key={i}
//                   className={`text-sm ${
//                     i < product.rating ? "text-primary" : "text-muted-foreground"
//                   }`}
//                 >
//                   ★
//                 </span>
//               ))}
//             </div>
//           )}
//         </div>

//         <Button
//           onClick={handleAddToCart}
//           className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
//         >
//           <ShoppingCart className="h-4 w-4 mr-2" />
//           Add to Cart
//         </Button>
//       </div>
//     </motion.div>
//   );
// }
